﻿using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IPLEntities;
using IPLBAL;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for Admin2.xaml
    /// </summary>
    public partial class Admin_Roles : Window
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        //SqlCommand cmdObj;
        //SqlParameter parmObj;
        //SqlDataReader rdrStudent = null;
        DataTable dtStudent = new DataTable();
        public Admin_Roles()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Roles p1 = new Roles
                {
                    RoleId = int.Parse(textRollId1.Text),
                    RoleName = txtRoleName1.Text,
                };

                Roles_bal pb = new Roles_bal();
                int pid = pb.AddRolesbal(p1);
                MessageBox.Show(string.Format("New Role Added"),
                    "IPL Management System");

            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            View2 Window2 = new View2();
            Window2.Show();
        }

        //update
        private static void UpdateRoles(Roles editemp)
        {

            try
            {
                Roles_bal pb = new Roles_bal();
                bool employeeedited = pb.UpdateRolesBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("Roles Updated Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        //update
        //private static void UpdateMatch(Roles editemp)
        //{

        //    try
        //    {
        //        Roles_bal pb = new Roles_bal();
        //        bool employeeedited = pb.UpdateRolesBal(editemp);
        //        if (employeeedited)
        //        {
        //            MessageBox.Show("Roles edited Successfully");

        //        }
        //        else
        //            MessageBox.Show("Roles not updated");
        //    }
        //    catch (IPLException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }

        //}
        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
           
            Roles type = new Roles();
            type.RoleId = int.Parse(textRollId1.Text);
            type.RoleName = txtRoleName1.Text;
            UpdateRoles(type);

        }

        private void AdminRoles_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
