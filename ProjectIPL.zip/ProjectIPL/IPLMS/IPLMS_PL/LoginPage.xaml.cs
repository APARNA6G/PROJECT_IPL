﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using IPLEntities;
using IPLMS_PL;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (comboBoXUserType.Text == "")
                {
                    MessageBox.Show("please select an option");
                }
                if (comboBoXUserType.Text == "Admin")
                {
                    try
                    {

                        SqlConnection.ConnectionString = ConnectionString;
                        SqlConnection.Open();

                        string query = "select UserName,Password from [IPL].[RegisterDetails] Where UserName='" +
                              textBoxUserName.Text + "' and Password='" + passwordBox1.Password.ToString() + "'";
                        SqlCommand cmd = new SqlCommand(query, SqlConnection);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                           
                            MessageBox.Show("Login Successful");

                            LinkWindow admin = new LinkWindow(); //create your new form.
                            admin.Show(); //show the new form.
                            this.Close();


                        }
                        if (textBoxUserName.Text.Trim() == string.Empty)
                        {
                            MessageBox.Show("userName cannot be blank");
                        }
                        else if (passwordBox1.Password.ToString().Trim() == string.Empty)
                        {
                            MessageBox.Show("password box cannot be empty");

                        }
                        else if(!(dt.Rows.Count > 0))
                        {
                            MessageBox.Show("Invalid Username or Password");
                        }
                        
                    }
                    catch (SqlException)
                    {
                        throw;
                    }
                    finally
                    {
                        SqlConnection.Close();
                    }

                }
                 if (comboBoXUserType.Text == "Customer")
                {
                    
                    try
                    {

                        SqlConnection.ConnectionString = ConnectionString;
                        SqlConnection.Open();

                        string query = "select UserName,Password from [IPL].[RegisterDetails] Where UserName='" +
                              textBoxUserName.Text + "' and Password='" + passwordBox1.Password.ToString() + "'";
                        SqlCommand cmd = new SqlCommand(query, SqlConnection);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                       
                        if (dt.Rows.Count > 0)
                        {
                            //if (textBoxUserName.Text.Trim() == string.Empty)
                            //{
                            //    MessageBox.Show("userName cannot be blank");
                            //}
                            //else if (passwordBox1.Password.ToString().Trim() == string.Empty)
                            //{
                            //    MessageBox.Show("password box cannot be empty");

                            //}

                            MessageBox.Show("Login Successful");

                            Customer admin = new Customer(); //create your new form.
                            admin.Show(); //show the new form.
                            this.Close();


                        }
                        else
                        {
                            MessageBox.Show("Invalid Username or Password");
                        }

                    }
                    catch (SqlException)
                    {
                        throw;
                    }
                    finally
                    {
                        SqlConnection.Close();
                    }
                }
            }
            catch(Exception)
            {
                MessageBox.Show("UserName and Password Cannot be Empty");
            }



        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {

            Register main1 = new Register(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
