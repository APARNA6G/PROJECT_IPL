﻿using IPLBAL;
using IPLExceptions;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Drawing;
using Image = System.Drawing.Image;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for View_Team.xaml
    /// </summary>
    public partial class View_Team : Window
    {
        public View_Team()
        {
            InitializeComponent();
        }

        private void DgTeam_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                TeamBal st = new TeamBal();
                DataTable dt = st.DisplayTeamBal();
                DgTeam.ItemsSource = dt.DefaultView;


            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            finally
            {

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string TeamId = textBox_MatchId1.Text;
            SqlConnection connection = new SqlConnection();
            try
            {
                object data = null; ;
                byte[] image = null;
                connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;User ID=sqluser;Password=sqluser";
                connection.Open();
                SqlCommand command = new SqlCommand("[IPL].[Team_viewPhoto]", connection);
                command.Parameters.AddWithValue("@TeamId", TeamId);

                command.CommandType = CommandType.StoredProcedure;

                command.Connection = connection;

                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        data = reader.GetValue(0);


                    }
                    image = (byte[])data;
                    imgseeker.Source = byteArrayToImage(image);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private BitmapImage byteArrayToImage(byte[] byteArrayIn)
        {
            BitmapImage returnImage = null;
            try
            {
                MemoryStream stream = new MemoryStream();
                stream.Write(byteArrayIn, 0, byteArrayIn.Length);
                stream.Position = 0;
                Image img = Image.FromStream(stream);
                returnImage = new BitmapImage();
                returnImage.BeginInit();
                MemoryStream ms = new MemoryStream();
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                ms.Seek(0, SeekOrigin.Begin);
                returnImage.StreamSource = ms;
                returnImage.EndInit();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnImage;
        }
    }
}
