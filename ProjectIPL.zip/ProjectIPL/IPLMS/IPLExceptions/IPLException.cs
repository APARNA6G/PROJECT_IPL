﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLExceptions
{
        //[Serializable]
        public class IPLException : Exception
        {
            public IPLException() { }
            public IPLException(string message) : base(message) { }
            public IPLException(string message, Exception inner) : base(message, inner) { }
            //protected IPLException(
            //  System.Runtime.Serialization.SerializationInfo info,
            //  System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
        }   
}
