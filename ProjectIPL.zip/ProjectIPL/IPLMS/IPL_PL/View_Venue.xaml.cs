﻿using IPLBAL;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for View_Venue.xaml
    /// </summary>
    public partial class View_Venue : Window
    {
        public View_Venue()
        {
            InitializeComponent();
        }

        private void VenueGrid_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                VenueBal st = new VenueBal();
                DataTable dt = st.DisplayVenueBal();
                VenueGrid.ItemsSource = dt.DefaultView;


            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            finally
            {

            }
        }
    }
}
