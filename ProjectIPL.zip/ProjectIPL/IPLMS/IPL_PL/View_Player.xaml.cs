﻿using IPLBAL;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for View_Player.xaml
    /// </summary>
    public partial class View_Player : Window
    {
        public View_Player()
        {
            InitializeComponent();
        }

       

        private void DgViewplayer_Loaded(object sender, RoutedEventArgs e)
        {

            try
            {
                PlayerBal st = new PlayerBal();
                DataTable dt = st.DisplayPlayerBal();
                DgViewplayer.ItemsSource = dt.DefaultView;


            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            finally
            {

            }
        }
    }
}
