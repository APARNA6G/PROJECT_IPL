﻿using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IPLEntities;
using IPLBAL;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for UserRoles_Admin3.xaml
    /// </summary>
    public partial class UserRoles_Admin3 : Window
    {

        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        //SqlCommand cmdObj;
        //SqlParameter parmObj;
        //SqlDataReader rdrStudent = null;
        DataTable dtStudent = new DataTable();
        public UserRoles_Admin3()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserRoles p = new UserRoles
                {
                    UserId = int.Parse(textUserId1.Text),
                    RoleId = int.Parse(textRollId1.Text)
                   
                };

                User_Roles_Bal pb = new User_Roles_Bal();
                int pid = pb.AddUserRolesBAL(p);
                MessageBox.Show(string.Format("You have assigned user roles Successfully", pid),
                    "IpL Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            UserRolesView v2 = new UserRolesView(); //create your new form.
            v2.Show(); //show the new form.
            this.Close();

        }
        //update
        private static void UpdateUserRoles(UserRoles editemp)
        {

            try
            {
                User_Roles_Bal pb = new User_Roles_Bal();
                bool employeeedited = pb.UpdateUserRolesBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("employee Updated Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            UserRoles type = new UserRoles();
            type.UserId = int.Parse(textUserId1.Text);
            type.RoleId = int.Parse(textRollId1.Text);
            UpdateUserRoles(type);
        }

        private void Userinfo_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
