﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IPLBAL;
using IPLEntities;
using IPLExceptions;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for Admin_Add.xaml
    /// </summary>
    public partial class Admin_Add : Window
    {
        
        public Admin_Add()
        {
            InitializeComponent();
        }
        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
       // SqlCommand cmdObj;
        private void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Users u = new Users
                {
                    FirstName = textBoxFirstName.Text,
                    LastName = textBoxLastName.Text,
                    UserId = int.Parse(textBoxuserid.Text),
                    UserName = txtUserName1.Text,
                    Password = passwordBox1.Password.ToString()
                };

                IPLbal pb = new IPLbal();
                int pid = pb.adduserbal(u);
                MessageBox.Show(string.Format("Details Added Successfully"),
                    "IPL Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            View Window = new View();
            Window.Show();
        }

        //update
        private static void UpdateMatch(Users editemp)
        {

            try
            {
                IPLbal pb = new IPLbal();
                bool employeeedited = pb.UpdateUserBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("User Updated Successfully");

                }
                else
                    MessageBox.Show("User not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            Users type = new Users();
            type.FirstName = textBoxFirstName.Text;
            type.LastName = textBoxLastName.Text;
            type.Password = passwordBox1.Password.ToString();
            type.UserId = int.Parse(textBoxuserid.Text);
            type.UserName = txtUserName1.Text;
            
            UpdateMatch(type);

        }

        private void Useer_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        //private void Button_Click_1(object sender, RoutedEventArgs e)
        //{
        //    Admin2 admin2 = new Admin2(); //create your new form.
        //    admin2.Show(); //show the new form.
        //    this.Close();
        //}
    }
}