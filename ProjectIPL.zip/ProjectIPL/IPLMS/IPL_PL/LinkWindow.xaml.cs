﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for LinkWindow.xaml
    /// </summary>
    public partial class LinkWindow : Window
    {
        public LinkWindow()
        {
            InitializeComponent();
        }

        //users
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Admin_Add m = new Admin_Add(); //create your new form.
            m.Show(); //show the new form.
            this.Close();

        }
        //Roles
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Admin_Roles n = new Admin_Roles(); //create your new form.
            n.Show(); //show the new form.
            this.Close();
        }
        //user Roles
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            UserRoles_Admin3 p = new UserRoles_Admin3(); //create your new form.
            p.Show(); //show the new form.
            this.Close();
        }
        //Team
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Team_Window T = new Team_Window(); //create your new form.
            T.Show(); //show the new form.
            this.Close();
        }
        //Player
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Player_Window PW = new Player_Window(); //create your new form.
            PW.Show(); //show the new form.
            this.Close();
        }
        //Player Photo
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            PlayerPhotoWindow Pp = new PlayerPhotoWindow(); //create your new form.
            Pp.Show(); //show the new form.
            this.Close();
        }
        //match
        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            MatchWindow Pp = new MatchWindow(); //create your new form.
            Pp.Show(); //show the new form.
            this.Close();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            VenueWindow Pp = new VenueWindow(); //create your new form.
            Pp.Show(); //show the new form.
            this.Close();
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            Schedule main1 = new Schedule(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            TicketWindow main1 = new TicketWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            StatisticsWindow main1 = new StatisticsWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
