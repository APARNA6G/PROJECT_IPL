﻿using IPLBAL;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IPLEntities;
using System.Data;
using System.Data.SqlClient;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for Player_Window.xaml
    /// </summary>
    public partial class Player_Window : Window
    {
        DataSet dataSet = new DataSet();
        public Player_Window()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Players p = new Players
                {
                    PlayerId = int.Parse(txtPlayerId.Text),
                    TeamId = int.Parse(txtTeamId.Text),
                    Name = txtName.Text,
                    Age = int.Parse(txtAge.Text),
                    Speciality =txtSpecialit.Text


                };

                PlayerBal pb = new PlayerBal();
                int pid = pb.AddPlayerBAL(p);
                MessageBox.Show(string.Format("New Player Details Addded Succesfully"),
                    "IPL Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            View_Player player = new View_Player(); //create your new form.
            player.Show(); //show the new form.
            this.Close();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Playerinfo_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
