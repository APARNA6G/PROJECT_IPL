﻿using IPL_DAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPLBAL
{
    public class TeamBal
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateTeam(Team pro)
        {


            bool IsValidTeam = true;

            if (pro.TeamId.Equals(string.Empty))
            {
                IsValidTeam = false;
                sb.Append("TeamId cannot be blank " + Environment.NewLine);

            }
            if (pro.TeamId < 1)
            {
                IsValidTeam = false;
                sb.Append(Environment.NewLine + "TeamId should not be negative");
            }
            if (!Regex.Match(pro.TeamName, @"^[a-zA-Z]+$").Success)
            {
                IsValidTeam = false;
                sb.Append(Environment.NewLine + "TeamName should be Aphabets");
            }
            if (pro.TeamName.Equals(string.Empty))
            {
                IsValidTeam = false;
                sb.Append("TeamName cannot be blank " + Environment.NewLine);

            }
            if (pro.HomeGround.Equals(string.Empty))
            {
                IsValidTeam = false;
                sb.Append("HomeGround cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.HomeGround, @"^[a-zA-Z]+$").Success)
            {
                IsValidTeam = false;
                sb.Append(Environment.NewLine + "HomeGround should be Aphabets Only");
            }
            if (pro.Owner.Equals(string.Empty))
            {
                IsValidTeam = false;
                sb.Append("Owner name cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.Owner, @"^[a-zA-Z]+$").Success)
            {
                IsValidTeam = false;
                sb.Append(Environment.NewLine + "Owner should be Aphabets Only");
            }

            return IsValidTeam;
        }
        public int AddTeamBAL(Team pobj)
        {
            try
            {
                int pid = 0;
                TeamDal pd = new TeamDal();
                if (ValidateTeam(pobj))
                {
                    pid = pd.AddTeamDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        //UpdateTeamBal
        public bool UpdateTeamBal(Team upmatch)
        {
            bool Matchupdated = false;
            try
            {
                if (ValidateTeam(upmatch))
                {
                    TeamDal matchdal = new TeamDal();//give Dal class 
                    Matchupdated = matchdal.UpdateTeamDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Matchupdated;

        }
        //DeleteVenueBal
        public static bool DeleteVenueBal(string TeamId)
        {
            bool TeamDeleted = false;
            try
            {
                TeamDal deletedal = new TeamDal();
                TeamDeleted = deletedal.DeleteTeamDAL(TeamId);
            }
            catch (IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return TeamDeleted;
        }
        //DisplayTeamBal
        public DataTable DisplayTeamBal()
        {
            try
            {
                TeamDal sd = new TeamDal();
                DataTable dtProduct = sd.DisplayTeamDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No Team Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
