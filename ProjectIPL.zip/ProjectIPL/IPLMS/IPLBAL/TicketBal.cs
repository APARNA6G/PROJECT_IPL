﻿using IPL_DAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPLBAL
{
    public class TicketBal
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateTicket(Ticket pro)
        {


            bool IsValidTicket = true;
            if (pro.TicketId.ToString().Equals(string.Empty))
            {
                IsValidTicket = false;
                sb.Append("TicketId cannot be blank " + Environment.NewLine);

            }
            if (pro.TicketId < 1)
            {
                IsValidTicket = false;
                sb.Append(Environment.NewLine + "TicketId should not be negative");
            }
            //if (!(Regex.IsMatch(pro.TicketId.ToString(), @"[0-9]$")))
            //{
            //    IsValidTicket = false;
            //    sb.Append(Environment.NewLine + "TicketId  should greater than zero");
            //}
            if (pro.MatchId.ToString().Equals(string.Empty))
            {
                IsValidTicket = false;
                sb.Append("MatchId cannot be blank " + Environment.NewLine);

            }
            if (pro.MatchId < 1)
            {
                IsValidTicket = false;
                sb.Append(Environment.NewLine + "MatchId should not be negative");
            }
            //if (!(Regex.IsMatch(pro.MatchId.ToString(), @"[0-9]$")))
            //{
            //    IsValidTicket = false;
            //    sb.Append(Environment.NewLine + "MatchId  should greater than zero");
            //}
            if (pro.CategoryId.ToString().Equals(string.Empty))
            {
                IsValidTicket = false;
                sb.Append("CategoryId cannot be blank " + Environment.NewLine);

            }
            if (pro.CategoryId < 1)
            {
                IsValidTicket = false;
                sb.Append(Environment.NewLine + "CategoryId should not be negative");
            }
            //if (!(Regex.IsMatch(pro.CategoryId.ToString(), @"[0-9]$")))
            //{
            //    IsValidTicket = false;
            //    sb.Append(Environment.NewLine + "CategoryId  should greater than zero");
            //}
            if (!(Regex.IsMatch(pro.Price.ToString(), @"[0-9]$")))
            {
                IsValidTicket = false;
                sb.Append(Environment.NewLine + "Product Price should greater than zero");
            }
            if (pro.Price.ToString().Equals(string.Empty))
            {
                IsValidTicket = false;
                sb.Append("Product Price cannot be blank " + Environment.NewLine);

            }
            if (pro.Price < 1)
            {
                IsValidTicket = false;
                sb.Append(Environment.NewLine + "Price should not be negative");
            }
            return IsValidTicket;
        }
        //AddTicketBAL
        public int AddTicketBAL(Ticket pobj)
        {
            try
            {
                int pid = 0;
                TicketDal pd = new TicketDal();
                if (ValidateTicket(pobj))
                {
                    pid = pd.AddTicketDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        //DisplayTicketBal
        public DataTable DisplayTicketBal()
        {
            try
            {
                TicketDal sd = new TicketDal();
                DataTable dtProduct = sd.DisplayTicketDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No Student Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //UpdateTicketBal
        public bool UpdateTicketBal(Ticket upmatch)
        {
            bool Ticketupdated = false;
            try
            {
                if (ValidateTicket(upmatch))
                {
                    TicketDal matchdal = new TicketDal();
                    Ticketupdated = matchdal.UpdateTicketDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Ticketupdated;

        }
        //DeleteTicketBal
        public static bool DeleteTicketBal(string VenueId)
        {
            bool TicketDeleted = false;
            try
            {
                TicketDal deleteTicketdal = new TicketDal();
                TicketDeleted = deleteTicketdal.DeleteTicketDAL(VenueId);
            }
            catch (IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return TicketDeleted;
        }
    }
}
