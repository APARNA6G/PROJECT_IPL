﻿using IPL_DAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPLBAL
{
    public class BookingBAL
    {
        
        StringBuilder sb = new StringBuilder();
        private bool ValidateProduct(BookingEntity pro)
        {


            bool IsValidProduct = true;
            if (pro.Id.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("Id cannot be blank " + Environment.NewLine);

            }
            if (pro.FirstName.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("FirstName cannot be blank " + Environment.NewLine);

            }
            if (pro.Id.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("LastName cannot be blank " + Environment.NewLine);

            }
            if (pro.Age.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("LastName cannot be blank " + Environment.NewLine);

            }
            if (pro.NumberofTickets.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("LastName cannot be blank " + Environment.NewLine);

            }
            if(!Regex.Match(pro.FirstName, @"^[a-zA-Z]+$").Success)
            {
                IsValidProduct = false;
                sb.Append("FirstName Should Contain only Alphabets " + Environment.NewLine);
            }
            if (!Regex.Match(pro.LastName, @"^[a-zA-Z]+$").Success)
            {
                IsValidProduct = false;
                sb.Append("LastName Should Contain only Alphabets " + Environment.NewLine);
            }
            
            if (pro.Age<10)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "Age should greater than ten");
            }
            if (pro.Age < 1)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "NumberofTickets Should be Grater than Zero");
            }

            return IsValidProduct;
        }
        //AddBookingBAL
        public int AddBookingBAL(BookingEntity pobj)
        {
            try
            {
                int pid = 0;
                BookingDal pd = new BookingDal();
                if (ValidateProduct(pobj))
                {
                    pid = pd.AddBookingDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
    }
}
