﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using IPLEntities;
using IPLExceptions;
using IPL_DAL;
using System.Data;
using System.Data.SqlClient;

namespace IPLBAL
{
    public class IPLbal
    {
        
        StringBuilder sb = new StringBuilder();
        private bool ValidateIPL(Users pro)
        {


            bool IsValidIPL = true;
            if (pro.FirstName.Equals(string.Empty))
            {
                IsValidIPL = false;
                sb.Append("FirstName cannot be blank " + Environment.NewLine);

            }

            if (!Regex.Match(pro.FirstName, @"^[a-zA-Z]+$").Success)
            {
                IsValidIPL = false;
                sb.Append(Environment.NewLine + "FirstName should be Alphabets Only");
            }
            if (pro.LastName.Equals(string.Empty))
            {
                IsValidIPL = false;
                sb.Append("LastName cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.LastName, @"^[a-zA-Z]+$").Success)
            {
                IsValidIPL = false;
                sb.Append(Environment.NewLine + "LastName should be Alphabets");
            }
            if (pro.UserId.ToString().Equals(string.Empty))
            {
                IsValidIPL = false;
                sb.Append("UserId cannot be blank " + Environment.NewLine);

            }
            if (pro.Password.ToString().Equals(string.Empty))
            {
                IsValidIPL = false;
                sb.Append("Password cannot be blank " + Environment.NewLine);

            }
            if (pro.UserId<1)
            {
                IsValidIPL = false;
                sb.Append(Environment.NewLine + "UserId should not be negative");
            }
            
            if (pro.UserName.ToString().Equals(string.Empty))
            {
                IsValidIPL = false;
                sb.Append("UserName cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.UserName, @"^[a-zA-Z]+$").Success)
            {
                IsValidIPL = false;
                sb.Append(Environment.NewLine + "UserName should be Alphabets");
            }

            return IsValidIPL;
        }
            public int adduserbal(Users pobj)
            {
                try
                {
                    int pid = 0;
                    IPLdal pd = new IPLdal();
                    if (ValidateIPL(pobj))
                    {
                        pid = pd.AdduserDal(pobj);
                    }
                    else
                        throw new IPLException(sb.ToString());

                    return pid;
                }
                catch (IPLException)
                {
                    throw;
                }

            }
        public DataTable ViewUserBal()
        {
            try
            {
                IPLdal sd = new IPLdal();
                DataTable dtProduct = sd.ViewUserDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No User Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //UpdateUserBal
        public bool UpdateUserBal(Users upmatch)
        {
            bool Matchupdated = false;
            try
            {
                if (ValidateIPL(upmatch))
                {
                    IPLdal matchdal = new IPLdal();//give Dal class 
                    Matchupdated = matchdal.UpdateUserDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Matchupdated;

        }
    }


    
}
