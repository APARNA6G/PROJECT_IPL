﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public class ScheduleDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static ScheduleDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public ScheduleDal()
        {
            con = new SqlConnection(conStr);
        }
        //AddScheduleDAL
        public int AddScheduleDAL(SchedulEntity pboj)
        {
            int pid = 0;
            try
            {
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Schedule_Add]";
                //cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Schedule_Add]", con);
                cmd.CommandType = CommandType.StoredProcedure;
             
                cmd.Parameters.AddWithValue("@ScheduleId", pboj.ScheduleId);
                cmd.Parameters.AddWithValue("@MatchId", pboj.MatchId);
                cmd.Parameters.AddWithValue("@VenueId", pboj.VenueId);
                cmd.Parameters.AddWithValue("@Date", pboj.Date);
                cmd.Parameters.AddWithValue("@StartTime", pboj.StartTime);
                cmd.Parameters.AddWithValue("@EndTime", pboj.EndTime);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
            //    pid = int.Parse(cmd.Parameters["@SerialNumber"].Value.ToString());
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        //DisplayScheduleDal
        public DataTable DisplayScheduleDal()
        {
            DataTable dt = null;


            try
            {
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Schedule_display]";
                //cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Schedule_display]", con);
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //UpdateScheduleDal
        public bool UpdateScheduleDal(SchedulEntity pbo)
        {
            bool isScheduleedited = false;
            try
            {
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Schedule_update]";
                //cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Schedule_update]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ScheduleId", pbo.ScheduleId);
                cmd.Parameters.AddWithValue("@MatchId", pbo.MatchId);
                cmd.Parameters.AddWithValue("@VenueId", pbo.VenueId);
                cmd.Parameters.AddWithValue("@Date", pbo.Date);
                cmd.Parameters.AddWithValue("@StartTime", pbo.StartTime);
                cmd.Parameters.AddWithValue("@EndTime", pbo.EndTime);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isScheduleedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isScheduleedited;

        }
        //DeleteScheduleDAL
        public bool DeleteScheduleDAL(string ScheduleId)
        {
            bool ScheduleDeleted = false;
            try
            {
                con.Open();
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Schedule_delete]";
                //cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Schedule_delete]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ScheduleId", ScheduleId);

                int NumberOfRowsdeleted = cmd.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    ScheduleDeleted = true;
            }
            catch (Exception ex)
            {
                throw new IPLException(ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return ScheduleDeleted;
        }
    }
}
