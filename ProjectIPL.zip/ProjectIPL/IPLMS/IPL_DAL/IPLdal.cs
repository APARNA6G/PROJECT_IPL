﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IPLEntities;
using IPLExceptions;

namespace IPL_DAL
{
    public class IPLdal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static IPLdal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public IPLdal()
        {
            con = new SqlConnection(conStr);
        }
        public int AdduserDal(Users pboj)
        {
            int pid = 0;
            try
            {
                cmd = new SqlCommand("[IPL].[Users_Add1]", con);

                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Users_Add1]";
                //cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.Add("@UserId", SqlDbType.Float);
                //cmd.Parameters["@UserId"].Direction = ParameterDirection.Output;


                cmd.Parameters.AddWithValue("@UserId", pboj.UserId);
                cmd.Parameters.AddWithValue("@UserName", pboj.UserName);
                cmd.Parameters.AddWithValue("@Password", pboj.Password);
                cmd.Parameters.AddWithValue("@FirstName", pboj.FirstName);
                cmd.Parameters.AddWithValue("@LastName", pboj.LastName);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                pid = int.Parse(cmd.Parameters["@UserId"].Value.ToString());
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        public DataTable ViewUserDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand("[IPL].[Users_display]", con);
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Users_display]";
                //cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //update
        public bool UpdateUserDal(Users pbo)
        {
            bool isemployeeedited = false;
            try
            {

                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Users_Update]";
                //cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Users_Update]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserId", pbo.UserId);
                cmd.Parameters.AddWithValue("@UserName", pbo.UserName);
                cmd.Parameters.AddWithValue("@Password", pbo.Password);
                cmd.Parameters.AddWithValue("@FirstName", pbo.FirstName);
                cmd.Parameters.AddWithValue("@LastName", pbo.LastName);
               
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isemployeeedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
    }
}
