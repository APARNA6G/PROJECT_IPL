﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public class MatchDal
    {
        //AddMatchDal
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static MatchDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public MatchDal()
        {
            con = new SqlConnection(conStr);
        }
        public int AddMatchDal(MatchEntities pboj)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Match_1_Add]";
                //cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Match_1_Add]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@MatchId", pboj.MatchId);
                cmd.Parameters.AddWithValue("@TeamOneId", pboj.TeamOneId);
                cmd.Parameters.AddWithValue("@TeamTwoId", pboj.TeamTwoId);
                cmd.Parameters.AddWithValue("@VenueId", pboj.VenueId);
                cmd.Parameters.AddWithValue("@ScheduleId", pboj.ScheduleId);
                cmd.Parameters.AddWithValue("@PhotoGroupId", pboj.PhotoGroupId);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@SerialNumber"].Value.ToString());
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        public DataTable DisplayMatchDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand("[IPL].[Match_1_display]", con);
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Match_1_display]";
                //cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //update
        public bool UpdateMatch(MatchEntities pbo )
        {
            bool isemployeeedited = false;
            try
            {
                //connection.ConnectionString = ConnectionString;
                //connection.Open();

                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[Match_1_Update]";
                //cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Match_1_Update]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@MatchId", pbo.MatchId);
                cmd.Parameters.AddWithValue("@TeamOneId", pbo.TeamOneId);
                cmd.Parameters.AddWithValue("@TeamTwoId", pbo.TeamTwoId);
                cmd.Parameters.AddWithValue("@VenueId", pbo.VenueId);
                cmd.Parameters.AddWithValue("@ScheduleId", pbo.ScheduleId);
                cmd.Parameters.AddWithValue("@PhotoGroupId", pbo.PhotoGroupId);
              
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isemployeeedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
        //DeleteVenueDAL
        public bool DeleteVenueDAL(string MatchId)
        {
            bool VenueDeleted = false;
            try
            {
                //{
                   
                //    cmd = new SqlCommand();
                //    cmd.CommandText = "[IPL].[Match_1_delete]";
                //    cmd.Connection = con;
                cmd = new SqlCommand("[IPL].[Match_1_delete]", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@MatchId", MatchId);
                con.Open();

                int NumberOfRowsdeleted = cmd.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    VenueDeleted = true;
            }
            catch (Exception ex)
            {
                throw new IPLException(ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return VenueDeleted;
        }
    }
}