﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IPL_DAL
{
    public class BookingDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static BookingDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public BookingDal()
        {
            con = new SqlConnection(conStr);
        }
        //AddBookingDal
        public int AddBookingDal(BookingEntity pboj)
        {
            int pid = 0;
            try
            {
                cmd = new SqlCommand("[IPL].[BookedTickets_Add3]", con);
                //cmd = new SqlCommand();
                //cmd.CommandText = "[IPL].[BookedTickets_Add3]";
                //cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Id", pboj.Id);
                cmd.Parameters.AddWithValue("@FirstName", pboj.FirstName);
                cmd.Parameters.AddWithValue("@LastName", pboj.LastName);
                cmd.Parameters.AddWithValue("@Age", pboj.Age);
                cmd.Parameters.AddWithValue("@NumberofTickets", pboj.NumberofTickets);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
              }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
    }
}
