﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
     public class Ticket
    {
      
        public int TicketId { get; set; }
        public int MatchId { get; set; }
        public int CategoryId { get; set; }
        public float Price { get; set; }

    }
}
