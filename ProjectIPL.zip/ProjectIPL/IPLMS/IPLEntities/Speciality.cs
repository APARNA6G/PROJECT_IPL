﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
    public class Speciality
    {
        public int SpecialityId { get; set; }
        public string SpecialityDescription { get; set; }
    }
}
