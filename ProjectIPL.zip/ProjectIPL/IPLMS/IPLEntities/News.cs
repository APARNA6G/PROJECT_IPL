﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
     public class News
    {
        //Id, NewsDate, MatchId, Description, MatchPhotoId
        public int NewsId { get; set; }
        public DateTime NewsDate { get; set; }
        public int MatchId { get; set; }
        public string Description { get; set; }
        public int MatchPhotoId { get; set; }

    }
}
