﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
    public class Statistics
    {
        //: TeamId, Played, Won, Lost, Tied, N/R, NetRR, For Against, Pts, From
        public int TeamId { get; set; }
        public string Played { get; set; }
        public string status  { get; set; }
        
        public float NetRunRate { get; set; }
        public float NetRequiredRunRate { get; set; }
        public string ForAgainst { get; set; }
        public int Points { get; set; }
        public string From { get; set; }

    }
}
